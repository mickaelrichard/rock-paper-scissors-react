import Game from "./game";
import Login from "./login";
import Signup from "./signup";
import LandingPage from "./landingPage";

export { Game, Signup, Login, LandingPage };
