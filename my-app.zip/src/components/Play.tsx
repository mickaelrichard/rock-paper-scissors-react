const Play = () => {
  return <div>Play</div>;
};

export default Play;
