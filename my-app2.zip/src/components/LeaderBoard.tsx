import React from "react";

const LeaderBoard = () => {
  return <div className="leaderBoard-container">leaderboard</div>;
};

export default LeaderBoard;
