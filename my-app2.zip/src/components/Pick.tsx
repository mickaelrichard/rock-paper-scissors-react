const Pick = () => {
  return <div>Pick</div>;
};

export default Pick;
